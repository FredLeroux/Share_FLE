package p3.MasterMind;

public class MmAppQuit {

	public MmAppQuit() {
		System.exit(1);
	}

}
