package p3.MasterMind;

public class MmMainMenu {

	public MmMainMenu() {
		new MmMenuHead("Main Menu");
		new MmDisplayMenu();

	}
}
