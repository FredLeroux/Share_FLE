package p3.MasterMind;

class MmMenuHeadDisplay extends MmMenuHead{

	public MmMenuHeadDisplay() {
		super(title);
		System.out.println("OpenClassRooms Projet 3: Mettez votre logique � l'�preuve.");
		System.out.println("Recherche +/- and MasterMind Game");
		System.out.println("Author : Fr�d�ric Leroux");
		System.out.print("\n");
		System.out.println(">--"+title+"--<");
		System.out.print("\n");
	}

}
