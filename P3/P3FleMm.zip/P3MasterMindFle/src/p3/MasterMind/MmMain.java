package p3.MasterMind;

public class MmMain {

	public MmMain() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new MmMenuConstruct();
		
		
		new MmRandomGenerator();
		}
	}


