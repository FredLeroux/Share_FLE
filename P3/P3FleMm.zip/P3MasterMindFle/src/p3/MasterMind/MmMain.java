package p3.MasterMind;

public class MmMain {

	public static void main(String[] args) {
		/**
		 * Project status Menu Built Ok Genrated random number Done
		 * 
		 * TODO Comparison between secret code and operator proposition for challenger
		 * game 
		 * Implement : 	D�fenseur
		 * 				mode Duel 
		 * 				mode Dev mode 
		 * 				Configuration using config.properties 
		 * 				Rules 
		 * 				Log 
		 * 				JavaDoc
		 * ALMOST EVERYTHING
		 * 
		 */

		// Note: this project is not finalized./

		new MmMainMenu();

	}

}
